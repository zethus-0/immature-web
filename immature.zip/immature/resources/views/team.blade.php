
@extends('layouts.app')
@section('content')
<section class="relative bg-black overflow-hidden">
 

    <div class="grid container">
    <div style="background-color:white">
        <h1 class="text-center pt-3 font-semibold text-4xl heading">Meet Our Team</h1>

        <div class="flex flex-wrap -mx-2 overflow-hidden sm:-mx-1 md:-mx-1 lg:-mx-1 xl:-mx-1">
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Aaminah </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Joseph </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Hiqmah </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Awais </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Akmol </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Soheer </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Manjot </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>
            <div class="my-2 px-2 w-1/3 overflow-hidden sm:my-1 sm:px-1 md:my-1 md:px-1 lg:my-1 lg:px-1 lg:w-1/2 xl:my-1 xl:px-1 xl:w-1/3">      
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Farhan </h3>
                        <h5 class="font-semibold text-lg">Team Member </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>   
            </div>

            
            

        </div>


        <!-- <div class="h-56 gap-4 grid grid-cols-3">
            
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>

                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                </div>

                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                </div>
            
        </div>
        <div class="h-56 gap-4 grid grid-cols-3">
            
                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                    
                </div>

                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                </div>

                <div class="m-4 rounded bg-purple-300 profiles">
                    <div class="p-6 profile">

                        <h3 class="font-semibold text-2xl name"> Dylan </h3>
                        <h5 class="font-semibold text-lg">Team Leader </h5>
                        <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                    </div>
                </div>
            
        </div> -->
    </div>
</div>   

@endsection
